/*
1. Sa se citeasca un sir de maxim 1000 de numere dintr-un fisier de intrare. Fiecare numar este scris pe o linie. Sirul
de numere va fi stocat intr-un vector. Sortati acest vector folosind un algoritm de sortare la alegerea voastra si
afisati-l pe ecran. Se vor folosi urmatoarele functii pentru citirea din fisier: fopen, fgets, fclose, Pentru conversia
din string in numar folositi atoi.
*/
#include <iostream>
#include <fstream>
#include <stdlib.h>
using namespace std;

void myfile_to_vector(int *v){
    fstream myfile ("..\\L01_P01.txt");
    string line;
    if (myfile.is_open()){
        int i=-1;
        while ( getline (myfile,line) ){
            i++;
            v[i]=atoi(line.c_str());
        }
        myfile.close();
    }
    else cout << "Unable to open file";
}
void vector_afisare(int *v, int n){
    for (int i=0;i<n;i++){
        cout << v[i] << " ";
    }
    cout << endl;
}
void sortare_vector(int *v, int n){
    for (int i=0;i<n-1;i++){
        for (int j=i+1;j<n;j++){
            if (v[i]>v[j]){
                int aux=v[i];
                v[i]=v[j];
                v[j]=aux;
            }
        }
    }
}


int main() {
    int n=10;
    int v[n]={0};
    myfile_to_vector(v);
    vector_afisare(v,n);
    sortare_vector(v,n);
    vector_afisare(v,n);
    return 0;
}
