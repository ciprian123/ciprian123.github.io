/*
Problema 2: Lucru cu pointeri. Se considera o matrice care reprezinta o imagine de n x m. Sa se deseneze un cerc cu
centrul dat si o anumita raza. Functia care deseneaza cercul insa va primi un pointer catre primul element al matricii.
Un element din matrice are valoarea 1 daca pe pozitia respectiv avem un punct vizibil, altfel are valoarea 0.
D(P1,P2) = SQRT ((P1.x - P2.x)*(P1.x - P2.x)+(P1.y - P2.y)*(P1.y - P2.y))
*/

#include <iostream>
using namespace std;
#include <math.h>

#define MATRIX_HEIGHT 6
#define MATRIX_WIDTH 5

int Matrix[MATRIX_HEIGHT][MATRIX_WIDTH]={0};

void matrix_afisare(int *m){
    for (int i=0;i<MATRIX_HEIGHT;i++){
        for(int j=0;j<MATRIX_WIDTH;j++){
            cout << m[i*MATRIX_WIDTH+j] << " ";
        }
        cout << endl;
    }

}
void Circle(int* m,int cx,int cy,int ray) {
    for (int i=0;i<MATRIX_HEIGHT;i++){
        for(int j=0;j<MATRIX_WIDTH;j++){
            if (int(sqrt((cx-i)*(cx-i)+(cy-j)*(cy-j)))==ray) m[i*MATRIX_WIDTH+j]=1;
        }
    }
}

int main(){
    matrix_afisare(&Matrix[0][0]);
    cout << "-------------" << endl;
    Circle(&Matrix[0][0],2,2,2);
    matrix_afisare(&Matrix[0][0]);
    return 0;
}